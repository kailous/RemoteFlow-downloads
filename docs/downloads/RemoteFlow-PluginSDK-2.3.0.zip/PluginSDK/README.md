# RemoteFlow 卡片插件 SDK 2.3.0

**基础展示元素是卡片。** 插件可以独立开发每张卡片的完整 UI，包括本地图片、远程图片加载、富文本、按钮、进度条、滑块、列表和自定义绘制。容器负责卡片外框、排列、自适应窗口、焦点与遥控路由，卡片内部布局和交互由插件决定。

宿主支持 ABI 2 原生卡片和 ABI 1 旧版菜单。新版卡片使用 [RemoteFlowCardPlugin.h](RemoteFlowCardPlugin.h)，与宿主之间只交换 C ABI 和 AppKit NSView；插件内部可以使用 AppKit，也可以通过 NSHostingView 使用 SwiftUI。

## 统一设置与控件

SDK 2.1 新增声明式设置菜单与统一控件库：[设置菜单与 UI 控件指南](SettingsAndControls.md)。插件通过 `settings.json` 声明设置项，宿主统一渲染并保存；通过 `RemoteFlowSettings.h` 接收配置。卡片内可复用 `RemoteFlowUI.h`（AppKit）或 `RemoteFlowUI.swift`（SwiftUI）的控件和主题。ABI 1/2 保持兼容。

SDK 2.2 新增 [RemoteFlowProgressLayout.h](RemoteFlowProgressLayout.h)：标准进度卡片的固定尺寸约定，所有带播放进度的卡片都应使用。具体数值见文末[标准进度卡片](#标准进度卡片)。

SDK 2.3（宿主 1.5 起）新增签名与信任策略，见[签名与信任](#签名与信任)；C ABI 与清单 schema 不变。

## 编译与安装图片卡片示例

```sh
zsh PluginSDK/Examples/RichCards/build.sh /private/tmp/RichCards.bundle
```

在菜单设置中点“安装插件”，导入输出的 `.bundle`，然后打开灵动岛：

- 音乐卡片：封面 PNG、标题、播放/上一首/下一首按钮、进度条、音量滑块和可展开列表。
- 图片卡片：独立图片、标题和说明，由插件自由布局。
- 方向键选择卡片，确定进入卡片，方向键在内部控件间移动，确定操作；音量滑块选中时左右键调整数值。
- 展开播放列表会在**菜单保持打开时**撑高卡片和容器，再次操作会收起。
- 返回退出卡片内部操作，再次返回关闭容器；菜单键或主页键直接关闭容器。

选择安装项后，其统一设置面板可配置卡片显隐、曲目名称、说明、自定义封面、音量、宽度和显示模式。示例播放操作用于演示 UI 状态，不连接真实媒体播放器。示例包内附带原创 PNG，无需网络。每次打开创建新视图，示例状态在本次展示期间保留。

旧 ABI 1 示例仍可编译使用：

```sh
zsh PluginSDK/Examples/HelloMenu/build.sh /private/tmp/HelloMenu.bundle
```

它演示简单菜单项和 3 / 24 项数量切换；复杂 UI 请以 RichCards 为起点。

## 插件包与清单

```text
RichCards.bundle/
  Contents/
    Info.plist                         # CFBundleExecutable 指向 RichCards
    MacOS/RichCards                     # 与宿主架构兼容的 Mach-O bundle
    Resources/menu-plugin.json         # 静态安装清单
    Resources/Artwork.png              # 插件自己的资源
    Resources/settings.json            # 可选，宿主渲染的统一设置菜单
    _CodeSignature/                    # codesign 生成
```

```json
{
  "schemaVersion": 1,
  "identifier": "com.example.my-cards",
  "version": "2.0.0",
  "author": "Example",
  "title": "我的卡片插件",
  "symbolName": "rectangle.on.rectangle"
}
```

清单 schema 保持为 1，C ABI 由二进制入口返回，二者独立。`identifier` 是更新身份；安装列表用清单标题和图标，实际卡片内容来自插件运行时。

插件包不支持符号链接，资源和依赖应完整置于包内；动态依赖可使用 `@loader_path`。创建视图时会传入**安装副本**的 Bundle 路径，应从该路径读取资源，不应依赖源码目录、原始安装来源或当前工作目录。异步加载远程图片及其缓存、失败状态由插件实现。

## ABI 2：原生卡片

所有入口及尺寸通知均在主线程使用。每个插件一次可提供最多 100 张卡片，描述 JSON 最多 1 MB，卡片 ID 唯一且非空。

| 导出入口 | 要求 |
| --- | --- |
| `remoteflow_menu_abi_version()` | 返回 `REMOTEFLOW_CARD_ABI_VERSION`（2） |
| `remoteflow_menu_content()` | 返回插件拥有的 UTF-8 卡片描述数组；宿主复制后不释放字符串 |
| `remoteflow_card_create_view(card_id, bundle_path)` | 返回一个 **+1 retain** 的 NSView 指针，宿主接管该引用 |
| `remoteflow_card_handle_remote(view, event, pressed)` | 借用 NSView 指针，返回 1 表示已处理，0 表示未处理 |
| `remoteflow_card_will_close(view)` | 可选；在卡片移除前停止计时器、订阅和异步任务；不释放传入指针 |

卡片描述示例：

```json
[
  {"id":"player","title":"音乐卡片","preferredWidth":520,"preferredHeight":292},
  {"id":"photo","title":"图片卡片","preferredWidth":280,"preferredHeight":292}
]
```

`preferredWidth` / `preferredHeight` 表示卡片**内部内容**所需的 pt 尺寸，不含宿主外框和标题栏。省略时采用视图 `fittingSize`，无有效尺寸时回退到 480 × 280。宿主对宽度限制为 160–4096 pt（`isCompact: true` 时为 96–4096 pt）、高度 80–4096 pt；卡片之间可使用不同尺寸，按可用宽度换行排列。

创建 AppKit 视图：

```objc
void *remoteflow_card_create_view(const char *card_id, const char *bundle_path) {
    NSView *view = /* 插件自己的完整 UI */;
    return (__bridge_retained void *)view;
}
```

创建 SwiftUI 视图的桥接形式：

```swift
@_cdecl("remoteflow_card_create_view")
func createCard(_ cardID: UnsafePointer<CChar>,
                _ bundlePath: UnsafePointer<CChar>) -> UnsafeMutableRawPointer? {
    MainActor.assumeIsolated {
        let view = NSHostingView(rootView: MyCardView())
        return Unmanaged.passRetained(view).toOpaque()
    }
}
```

插件还需导出表中的 ABI、内容及遥控入口。宿主不接收 SwiftUI 泛型值。每次创建返回独立 NSView；不要把同一个视图同时交给多个卡片。传入的 C 字符串只在调用期间有效，需要长期使用时应复制。

## 卡片内遥控与鼠标

| 状态 | 行为 |
| --- | --- |
| 选择卡片 | 容器按卡片几何位置处理方向键，确定进入卡片 |
| 进入卡片 | 插件收到 `enter`，`pressed=1`；可选中第一个内部控件 |
| 内部操作 | 插件收到 `up/down/left/right/ok` 的按下（1）和抬起（0） |
| 退出内部操作 | 容器先释放仍按住的键，再发送 `leave`，`pressed=1` |
| 返回键 | 内部操作时退出到卡片选择；卡片选择时关闭容器 |
| 菜单 / 主页键 | 直接关闭容器；始终由宿主保留 |

卡片可用可选字段 `handlesVolumeKeys: true` 声明使用音量键。卡片内部操作时，或直接选中小卡片（`isCompact: true`）时，宿主发送 `wantsVolumeKeys`（`pressed=1`）询问当前焦点是否接收音量键。查询应只读取状态。返回 1 时，宿主转发 `volumeUp` / `volumeDown` 的按下和抬起，并沿用宿主的原生按键拦截机制。返回 0 时音量键走原有路径。旧版宿主会忽略该字段。

卡片可在描述中提供 `remoteHint`，由宿主显示在底部按键说明栏。`activeRemoteHint` 可在卡片内部操作期间替换底栏的方向键提示。同一插件中连续声明 `layoutRow` 的卡片会组成一块区域，相同字符串标识区域内的同一行。这块区域和其他卡片横向并排。超出视窗的内容以卡片或整块区域为单位吸附切换。区域内可交互的卡片可声明 `replacesGroupOnEnter: true`，在操作期间占用整块区域，退出后恢复原布局。小卡片仍可使用 `showsHeader: false` 隐藏标题栏，并用 `handlesActivation: true` 直接处理选中时的 OK。可交互或处理直接激活的小卡片在未进入内部操作时，也可以点击整张卡片来触发同一操作。

进入卡片的那次确定键仅触发 `enter`，不会立即触发内部按钮。卡片内返回 0 的事件也由容器消费，避免误操作其他绑定。插件负责内部控件焦点、焦点高亮、按钮动作、滑块调整等；宿主不知道插件内部控件结构。

鼠标可直接操作插件原生控件；卡片头部也有“进入卡片”按钮。边框用于区分卡片焦点和内部操作状态。文字输入等 AppKit 控件可按需让浮动面板成为 key window；容器不抢占主应用的 main window。

## 打开期间实时撑开

内容变化时，插件应更新自己的 UI，并请求新尺寸：

```objc
RFCardRequestSize(view, 520, 472);
```

Swift 等实现可发送相同通知：

```swift
NotificationCenter.default.post(
    name: Notification.Name("RemoteFlowPluginCardSizeDidChange"),
    object: hostingView,
    userInfo: ["width": 520.0, "height": 472.0]
)
```

`object` 必须是创建入口交给宿主的根 NSView，通知必须在主线程发送，尺寸为有限正数。宿主会保留本次卡片对象及交互状态，重新排列并调整灵动岛尺寸；不需要关闭重开。无效尺寸会回退或限幅，卡片关闭后的通知被忽略。

容器保持屏幕顶部居中并保留刘海空间，在屏幕边界内先展开、再纵向滚动。单张卡片超出屏幕宽度时保留内容宽度并提供内部横向滚动；插件仍应尽量使用自适应布局，遥控聚焦控件时可调用 `scrollRectToVisible` 使其可见。卡片描述列表每次打开刷新；实时通知调整现有卡片尺寸，不增删本次展示中的卡片。

## 生命周期、签名与兼容

- 安装只复制并验证元数据、可执行文件及签名，不加载插件代码。打开菜单时加载代码并创建视图，关闭动画结束后调用 `will_close` 并释放宿主持有的视图。
- 所有入口应快速返回。耗时工作自行异步处理，更新 UI 与发送尺寸通知时回到主线程；在 `will_close` 里取消任务，避免已关闭 UI 继续产生副作用。
- 安装到 Application Support/RemoteFlow/MenuPlugins 的独立 UUID 路径。同 identifier 更新保留安装位置和启用状态，不覆盖正在加载的 Mach-O；原生卡片区域先于旧版快捷项区域展示。
- 已加载代码不做 `dlclose`，旧包在下一次启动清理。更新包含同名 Objective-C 类的插件后应重启应用；原生类名使用插件专属前缀。
- 卸载移除菜单入口。当前展示的卡片在本次容器关闭时清理，后台任务需由插件的生命周期入口停止。
- 导出复制完整签名包；安装列表的本地名称、图标修改不写回签名包。
- 原生代码在宿主进程执行并共享权限、阻塞与崩溃风险。签名完整性校验不等于信任发布者，分发前仍需在实际签名、公证和隔离属性环境验证。

## 签名与信任

宿主对原生插件**默认拒绝**，安装前必须通过信任策略：

- **临时（ad-hoc）签名**：仅当用户在插件管理"安全"设置中开启"开发者模式"后允许安装。适合本地开发与自用，不适合对外分发。
- **团队签名**（Developer ID 等携带 Team ID 的证书）：用户需先在"安全"设置中信任该 Team ID，之后该团队的插件可安装。
- **其他签名**（自签名等）一律拒绝。

安装时宿主记录插件包的签名指纹（cdhash），之后每次加载都会比对：安装后直接替换或篡改已装 bundle（即使重新有效签名）会被拒绝加载。**发布更新请通过宿主"安装插件"按相同 identifier 覆盖安装**，不要在磁盘上替换已装 bundle。

升级到宿主 1.5 之前已安装的插件会自动继承一次：宿主记录其指纹并继续可用，无需用户操作；继承插件同样受指纹比对保护。

正式分发建议使用 Developer ID 签名（构建脚本通过 `CODE_SIGN_IDENTITY` 指定证书），并在发布说明中告知用户提前信任你的 Team ID。示例构建脚本默认使用 ad-hoc 签名，供开发调试。正式 Hardened Runtime 仍保留 Library Validation，通常要求插件与宿主同 Team ID 签名。

SDK 2.1 保留 [RemoteFlowMenuPlugin.h](RemoteFlowMenuPlugin.h) 中 ABI 1 的菜单接口，旧二进制插件继续使用。ABI 2 插件需要新版宿主，旧宿主会报告不支持的 ABI；原生卡片插件不需要导出 `remoteflow_menu_execute`。

## 标准进度卡片

使用 [RemoteFlowProgressLayout.h](RemoteFlowProgressLayout.h) 的固定尺寸。采用标准进度布局的卡片内容高度为 180 pt，宽度由插件决定。只读进度条高 3 pt，距卡片底边 18 pt，左右各缩进 22 pt。时间放在进度条上方，间距 7 pt，左对齐，使用 11 pt 等宽数字，格式为「已播放 / 总时长」。使用 `showsHeader: false` 让内容高度与卡片高度一致。
