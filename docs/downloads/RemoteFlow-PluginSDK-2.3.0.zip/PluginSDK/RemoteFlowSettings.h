#ifndef REMOTEFLOW_SETTINGS_H
#define REMOTEFLOW_SETTINGS_H
#include "RemoteFlowMenuPlugin.h"
#ifdef __cplusplus
extern "C" {
#endif
// Optional extension for ABI 1 and 2. Declare fields in Contents/Resources/settings.json.
// Called with a complete flat object of validated values BEFORE menu content/view creation,
// and when the user applies settings. Main thread; strings are borrowed for this call.
// Return NULL on success, or a plugin-owned UTF-8 error string on rejection.
// Validate before mutating state. Update existing views if changes should apply live.
// The host persists accepted values by plugin identifier; code updates retain them.
const char *remoteflow_plugin_apply_settings(const char *json);
#ifdef __cplusplus
}
#endif
#endif
