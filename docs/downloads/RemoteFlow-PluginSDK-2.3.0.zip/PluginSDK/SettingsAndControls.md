# 插件设置与统一 UI 控件 · SDK 2.1

插件设置和卡片 UI 共享 RemoteFlow 的字体、蓝色强调色、深色背景、间距和焦点样式。

## 统一设置菜单

在插件包中放置 `Contents/Resources/settings.json`。宿主负责渲染分组、控件、说明、错误提示和“恢复默认 / 还原更改 / 应用设置”，插件不需要创建自己的设置窗口。

```json
{
  "schemaVersion": 1,
  "title": "插件设置",
  "description": "按需配置卡片",
  "sections": [{
    "id": "general",
    "title": "通用",
    "fields": [
      {"key":"showImage","type":"toggle","title":"显示图片","defaultValue":true},
      {"key":"caption","type":"text","title":"标题","defaultValue":"My card","maxLength":80},
      {"key":"volume","type":"slider","title":"音量","defaultValue":65,"minimum":0,"maximum":100,"step":1},
      {"key":"mode","type":"select","title":"布局","defaultValue":"compact","options":[
        {"value":"compact","title":"紧凑"}, {"value":"relaxed","title":"宽松"}
      ]}
    ]
  }]
}
```

| `type` | 标准控件 | 值类型 / 可选参数 |
| --- | --- | --- |
| `toggle` | 开关 | Boolean |
| `text` | 单行输入框 | String，`maxLength` |
| `multiline` | 多行文本编辑器 | String，`maxLength` |
| `slider` | 带数值显示的滑块 | Number，`minimum`、`maximum`、`step` |
| `number` | 数字输入与步进按钮 | Number，`minimum`、`maximum`、`step` |
| `select` | 下拉选择 | String，`options: [{value,title}]` |
| `file` | 路径输入与文件选择器 | String，`allowedExtensions`，例如 `["png","jpg"]` |

每个字段需要 `key/type/title/defaultValue`，可添加 `description`；分组需要 `id/title/fields`，也支持说明。`key` 在整个插件内唯一。最多 20 个分组、100 个字段、1 MB 声明文件；选择项最多 100 个且值唯一。未知控件类型、重复字段、不匹配的默认值会使安装失败。

数值必须有限且在范围内；滑块默认范围 0–100，数字默认范围 -1000000–1000000，步长默认 1。`step` 是 UI 增量，数字输入允许范围内任意有限值。文本默认最多 4096 字符，`maxLength` 最大 65536。`file` 可留空或输入路径，扩展名过滤作用于选择器，插件应在应用时验证实际文件和格式。

### 接收并应用配置

包含 [RemoteFlowSettings.h](RemoteFlowSettings.h)，导出可选入口：

```objc
const char *remoteflow_plugin_apply_settings(const char *json) {
    // json 是完整的平面配置，例如 {"showImage":true,"caption":"My card","volume":65,"mode":"compact"}。
    // 先解析并验证业务约束，失败返回插件拥有的 UTF-8 错误字符串。
    // 验证成功后更新插件状态，必要时更新已打开的视图并请求新尺寸。
    return NULL;
}
```

有 `settings.json` 的插件必须提供该入口。它在主线程调用：每次打开容器时先于内容查询和视图创建执行，用户点击“应用设置”时也会执行。打开设置面板只读取声明和当前值，不加载插件二进制；应用设置可能首次加载原生代码。配置字符串仅在本次调用期间有效。

不要在读取或解析配置时产生不可逆副作用。先验证再更新状态；拒绝配置时保留原状态。宿主只在接受并成功写盘后更新已保存值，写盘失败会尝试再次应用旧配置，因此入口应支持重复应用同一配置。

UI 编辑使用草稿，只有“应用设置”才提交；“恢复默认”仅修改草稿，仍需应用。宿主按稳定插件 identifier 保留配置，重启和更新包后仍在；卸载后配置随安装项移除。配置是本地普通 JSON，不提供密码或密钥存储。

声明新增字段使用默认值，旧字段的无效类型或越界值回退到新默认值。已移除字段仍保留在本地存储以便升级恢复，但不会传给插件。修改卡片数量在下次打开时生效；标题、音量、布局等能否实时更新由插件实现，示例会更新已打开的视图。

## 卡片内的 AppKit 控件

包含 [RemoteFlowUI.h](RemoteFlowUI.h)，这是 header-only 控件库，无需链接宿主 Swift 模块或额外 framework：

| API | 用途 |
| --- | --- |
| `RFUILabel(text, size, weight, color)` | 标签和标题 |
| `RFUIStack(views, orientation, spacing)` | 标准横向或纵向布局 |
| `RFUIImage(image, size)` | 等比显示的圆角图片 |
| `RFUIButton(title, primary, target, action)` | 主按钮 / 次按钮 |
| `RFUISymbolButton(symbol, label, target, action)` | SF Symbol 图标按钮 |
| `RFUITextField(value, placeholder, target, action)` | 文本输入 |
| `RFUIToggle(value, target, action)` | 开关 |
| `RFUISlider(value, minimum, maximum, target, action)` | 滑块 |
| `RFUISelect(titles, selectedIndex, target, action)` | 下拉选择 |
| `RFUIProgress(fraction)` | 0–1 进度条 |
| `RFUISetFocused(view, focused)` | 标准蓝色遥控焦点框及滚动到可见区域 |

控件仍是普通 AppKit 对象，可继续设置约束、辅助功能标签和业务回调。SDK 提供强调色、主次文字色和 8/12/20 pt 间距常量，支持自由组合；宿主已经提供卡片外框，插件不必重复绘制。

## 卡片内的 SwiftUI 控件

将 [RemoteFlowUI.swift](RemoteFlowUI.swift) 加入插件 target，复用 `RFUITheme`、`RFUISection`、`RFUIButton` 和 `.rfRemoteFocused(...)`，其余开关、滑块、输入框使用原生 SwiftUI 控件：

```swift
RFUISection("播放") {
    Toggle("显示图片", isOn: $showImage)
    Slider(value: $volume, in: 0...100)
    RFUIButton("播放") { play() }
        .rfRemoteFocused(focusedControl == .play)
}
```

SwiftUI UI 通过 NSHostingView 交给宿主。插件负责把遥控事件映射到自己的状态和操作；复用 UI 控件不会自动推断复杂界面的遥控焦点顺序。控件库随源码编译，更新样式后需重编译插件；统一设置菜单由宿主渲染，可随宿主升级更新样式。

完整的声明、回调和控件使用示例见 [Examples/RichCards](Examples/RichCards)。SDK 2.1 不改变 ABI 1/2，未声明设置的旧插件继续工作。
