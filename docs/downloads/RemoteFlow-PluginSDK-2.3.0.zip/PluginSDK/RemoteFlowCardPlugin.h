#ifndef REMOTEFLOW_CARD_PLUGIN_H
#define REMOTEFLOW_CARD_PLUGIN_H
#include "RemoteFlowMenuPlugin.h"
#define REMOTEFLOW_CARD_ABI_VERSION 2u
#ifdef __OBJC__
#import <AppKit/AppKit.h>
// Main-thread only. Sizes describe the plugin's content, excluding host card chrome.
static inline void RFCardRequestSize(NSView *view, double width, double height) {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RemoteFlowPluginCardSizeDidChange"
        object:view userInfo:@{@"width": @(width), @"height": @(height)}];
}
#endif
#ifdef __cplusplus
extern "C" {
#endif
// ABI 2 plugins export remoteflow_menu_abi_version() returning REMOTEFLOW_CARD_ABI_VERSION.
// remoteflow_menu_content() returns card descriptors:
// [{"id":"player","title":"Player","preferredWidth":520,"preferredHeight":292}]
// Optional showsHeader=false removes the host title/padding; isInteractive=false disables enter controls.
// Both default to true for older plugins. handlesPaging=true routes selected up/down without entering.
// handlesActivation=true sends selected OK directly to the plugin without entering. Optional handlesPaging=true forwards up/down on selection, without enter.
// symbolName is optional. preferred sizes are optional; NSView.fittingSize is the fallback.
// Return a +1 retained NSView (ObjC: (__bridge_retained void *)view).
// The host owns/relinquishes this retain; never release the pointer passed back to you.
// bundle_path locates the installed bundle's resources. Copy arguments if retained.
void *remoteflow_card_create_view(const char *card_id, const char *bundle_path);
// Borrowed NSView pointer. All calls on the main thread. Return 1 if handled, 0 otherwise.
// Events: enter/leave (pressed=1), up/down/left/right/ok (pressed=1 down, 0 up).
// Back exits card interaction; menu/home close the container. These are host-reserved.
// Optional isCompact=true lowers the minimum width to 96 pt.
// Consecutive cards declaring layoutRow form a group beside other plugins.
// Matching layoutRow strings share a centered row within the group.
// An interactive grouped card with replacesGroupOnEnter=true fills its group until leave.
// Optional remoteHint and activeRemoteHint add text to the host footer.
// With handlesVolumeKeys=true, an entered card or a selected compact card receives wantsVolumeKeys (pressed=1).
// Return 1 without side effects if it wants volumeUp/volumeDown for its current focus.
// A consumed volume key is released before leave, even if that focus has changed.
// Unknown/unhandled events are consumed by the container while inside a card.
int32_t remoteflow_card_handle_remote(void *view, const char *event, int32_t pressed);
// Optional: stop timers/subscriptions/work before this card is removed. Called once.
// The view may remain alive through the hide animation; do not release it here.
void remoteflow_card_will_close(void *view);
#ifdef __cplusplus
}
#endif
#endif
