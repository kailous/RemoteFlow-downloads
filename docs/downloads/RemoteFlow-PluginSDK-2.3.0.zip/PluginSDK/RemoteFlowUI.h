#ifndef REMOTEFLOW_UI_H
#define REMOTEFLOW_UI_H
#ifdef __OBJC__
#import <AppKit/AppKit.h>
// Header-only AppKit controls. No additional framework or host Swift types are linked.
static const CGFloat RFUISpacingSmall = 8;
static const CGFloat RFUISpacingMedium = 12;
static const CGFloat RFUISpacingLarge = 20;
static inline NSColor *RFUIAccentColor(void) { return [NSColor colorWithSRGBRed:0 green:106.0/255.0 blue:1 alpha:1]; }
static inline NSColor *RFUIPrimaryTextColor(void) { return NSColor.whiteColor; }
static inline NSColor *RFUISecondaryTextColor(void) { return [NSColor colorWithWhite:0.7 alpha:1]; }
static inline NSTextField *RFUILabel(NSString *text, CGFloat size, NSFontWeight weight, NSColor *color) {
    NSTextField *label = [NSTextField labelWithString:text];
    label.font = [NSFont systemFontOfSize:size weight:weight];
    label.textColor = color ?: RFUIPrimaryTextColor();
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    return label;
}
static inline NSStackView *RFUIStack(NSArray<NSView *> *views, NSUserInterfaceLayoutOrientation orientation, CGFloat spacing) {
    NSStackView *stack = [NSStackView stackViewWithViews:views];
    stack.orientation = orientation;
    stack.spacing = spacing;
    stack.alignment = orientation == NSUserInterfaceLayoutOrientationVertical ? NSLayoutAttributeLeading : NSLayoutAttributeCenterY;
    return stack;
}
static inline NSImageView *RFUIImage(NSImage *image, CGFloat size) {
    NSImageView *view = [NSImageView imageViewWithImage:image];
    view.imageScaling = NSImageScaleProportionallyUpOrDown;
    view.wantsLayer = YES;
    view.layer.cornerRadius = 16;
    view.layer.masksToBounds = YES;
    [view.widthAnchor constraintEqualToConstant:size].active = YES;
    [view.heightAnchor constraintEqualToConstant:size].active = YES;
    return view;
}
static inline NSButton *RFUIButton(NSString *title, BOOL primary, id target, SEL action) {
    NSButton *button = [NSButton buttonWithTitle:title target:target action:action];
    button.bezelStyle = NSBezelStyleRounded;
    button.font = [NSFont systemFontOfSize:12 weight:NSFontWeightMedium];
    if (primary) { button.bezelColor = RFUIAccentColor(); button.contentTintColor = NSColor.whiteColor; }
    return button;
}
static inline NSButton *RFUISymbolButton(NSString *symbol, NSString *label, id target, SEL action) {
    NSButton *button = [NSButton buttonWithImage:[NSImage imageWithSystemSymbolName:symbol accessibilityDescription:label]
                                        target:target action:action];
    button.bezelStyle = NSBezelStyleTexturedRounded;
    [button.widthAnchor constraintEqualToConstant:48].active = YES;
    [button.heightAnchor constraintEqualToConstant:40].active = YES;
    return button;
}
static inline NSTextField *RFUITextField(NSString *value, NSString *placeholder, id target, SEL action) {
    NSTextField *field = [NSTextField textFieldWithString:value];
    field.placeholderString = placeholder;
    field.font = [NSFont systemFontOfSize:14];
    field.target = target; field.action = action;
    return field;
}
static inline NSSwitch *RFUIToggle(BOOL value, id target, SEL action) {
    NSSwitch *control = [NSSwitch new];
    control.state = value ? NSControlStateValueOn : NSControlStateValueOff;
    control.target = target; control.action = action;
    return control;
}
static inline NSSlider *RFUISlider(double value, double minimum, double maximum, id target, SEL action) {
    return [NSSlider sliderWithValue:value minValue:minimum maxValue:maximum target:target action:action];
}
static inline NSPopUpButton *RFUISelect(NSArray<NSString *> *titles, NSInteger selected, id target, SEL action) {
    NSPopUpButton *control = [[NSPopUpButton alloc] initWithFrame:NSZeroRect pullsDown:NO];
    [control addItemsWithTitles:titles];
    if (selected >= 0 && selected < (NSInteger)titles.count) [control selectItemAtIndex:selected];
    control.target = target; control.action = action;
    return control;
}
static inline NSProgressIndicator *RFUIProgress(double fraction) {
    NSProgressIndicator *control = [NSProgressIndicator new];
    control.indeterminate = NO; control.minValue = 0; control.maxValue = 1;
    control.doubleValue = MIN(1, MAX(0, fraction));
    return control;
}
static inline void RFUISetFocused(NSView *view, BOOL focused) {
    view.wantsLayer = YES;
    view.layer.cornerRadius = 8;
    view.layer.borderWidth = focused ? 2 : 0;
    view.layer.borderColor = RFUIAccentColor().CGColor;
    if (focused) [view scrollRectToVisible:view.bounds];
}
#endif
#endif
