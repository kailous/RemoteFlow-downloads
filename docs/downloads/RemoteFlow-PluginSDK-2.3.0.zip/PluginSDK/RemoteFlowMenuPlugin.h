#ifndef REMOTEFLOW_MENU_PLUGIN_H
#define REMOTEFLOW_MENU_PLUGIN_H
#include <stdint.h>
#define REMOTEFLOW_MENU_SDK_VERSION "2.2.0"
#define REMOTEFLOW_MENU_ABI_VERSION 1u
#ifdef __cplusplus
extern "C" {
#endif
// ABI 1: all calls run on the macOS main thread, serialized by the host.
// Return 1. Export these symbols with default visibility.
uint32_t remoteflow_menu_abi_version(void);
// UTF-8 JSON array: [{"id":"hello","title":"Hello","symbolName":"hand.wave"}].
// At most 100 entries, unique nonempty IDs and titles, <= 1 MB of UTF-8 JSON.
// The host sizes the container from the combined menu content and display bounds.
// Column count is adaptive; never assume a fixed four-column grid or three rows.
// Long titles may wrap to two lines and then truncate. No pixel size fields are required.
// Content and layout refresh on each opening, not while the menu is already open.
// Host copies the string before another call. Plugin owns returned storage.
const char *remoteflow_menu_content(void);
// Called on remote OK or mouse click. command_id is valid only during this call.
// Return NULL on success, or a plugin-owned UTF-8 error string on failure.
// Return promptly; dispatch long work asynchronously within the plugin.
const char *remoteflow_menu_execute(const char *command_id);
#ifdef __cplusplus
}
#endif
#endif
