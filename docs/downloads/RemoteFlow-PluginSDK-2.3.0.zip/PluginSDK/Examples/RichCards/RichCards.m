#import <AppKit/AppKit.h>
#include "../../RemoteFlowCardPlugin.h"
#include <string.h>

#include "../../RemoteFlowUI.h"
#include "../../RemoteFlowSettings.h"

static NSDictionary *RFCardSettings;
static NSHashTable *RFActiveCardViews;
static NSString *RFContentJSON;
static id RFSetting(NSString *key, id fallback) { return RFCardSettings[key] ?: fallback; }

@interface RFDemoRichCardView : NSView
@property BOOL playing;
@property BOOL expanded;
@property BOOL gallery;
@property NSInteger focusIndex;
@property NSArray<NSControl *> *controls;
@property NSStackView *queue;
@property NSButton *play;
@property NSButton *expand;
@property NSSlider *volume;
@property NSTextField *volumeLabel;
@property NSTextField *trackLabel;
@property NSTextField *subtitleLabel;
@property NSImageView *artwork;
@property NSImage *bundledArtwork;
- (void)applySettings;
- (instancetype)initWithImage:(NSImage *)image gallery:(BOOL)gallery;
- (int32_t)remote:(NSString *)event pressed:(BOOL)pressed;
@end

@implementation RFDemoRichCardView
- (instancetype)initWithImage:(NSImage *)image gallery:(BOOL)gallery {
    self = [super initWithFrame:NSMakeRect(0, 0, gallery ? 280 : 520, 292)];
    if (!self) return nil;
    self.gallery = gallery;
    self.bundledArtwork = image;
    self.focusIndex = -1;
    self.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
    NSColor *white = RFUIPrimaryTextColor();
    NSColor *muted = RFUISecondaryTextColor();
    NSStackView *root;
    if (gallery) {
        NSImageView *scene = RFUIImage(image, 216);
        self.artwork = scene;
        root = RFUIStack(@[scene, RFUILabel(@"Evening, unhurried.", 17, NSFontWeightMedium, white),
                        RFUILabel(@"本地图片 · 插件自定义卡片", 11, NSFontWeightRegular, muted)],
                       NSUserInterfaceLayoutOrientationVertical, 10);
        self.controls = @[];
    } else {
        NSImageView *cover = RFUIImage(image, 148);
        self.artwork = cover;
        NSTextField *eyebrow = RFUILabel(@"NATIVE CARD / DEMO", 10, NSFontWeightSemibold, muted);
        self.trackLabel = RFUILabel(@"After the rain", 25, NSFontWeightSemibold, white);
        NSTextField *artist = RFUILabel(@"Quiet Hours · Evening Sessions", 12, NSFontWeightRegular, muted);
        self.subtitleLabel = artist;
        artist.maximumNumberOfLines = 2;
        [artist.widthAnchor constraintLessThanOrEqualToConstant:290].active = YES;
        NSButton *previous = [self button:@"backward.end.fill" action:@selector(previous:)];
        self.play = [self button:@"play.fill" action:@selector(togglePlay:)];
        NSButton *next = [self button:@"forward.end.fill" action:@selector(next:)];
        NSStackView *transport = RFUIStack(@[previous, self.play, next], NSUserInterfaceLayoutOrientationHorizontal, 12);
        NSStackView *details = RFUIStack(@[eyebrow, self.trackLabel, artist, transport], NSUserInterfaceLayoutOrientationVertical, 12);
        NSStackView *hero = RFUIStack(@[cover, details], NSUserInterfaceLayoutOrientationHorizontal, 22);
        NSProgressIndicator *progress = RFUIProgress(0.42);
        [progress.widthAnchor constraintEqualToConstant:200].active = YES;
        NSStackView *timeline = RFUIStack(@[RFUILabel(@"01:42", 10, NSFontWeightRegular, muted), progress,
                                        RFUILabel(@"04:08", 10, NSFontWeightRegular, muted)], NSUserInterfaceLayoutOrientationHorizontal, 12);
        self.volume = RFUISlider(65, 0, 100, self, @selector(changeVolume:));
        [self.volume.widthAnchor constraintEqualToConstant:160].active = YES;
        self.volumeLabel = RFUILabel(@"音量 65%", 11, NSFontWeightMedium, muted);
        self.expand = RFUIButton(@"展开播放列表", NO, self, @selector(toggleQueue:));
        self.expand.bezelStyle = NSBezelStyleRounded;
        NSStackView *bottom = RFUIStack(@[self.volume, self.volumeLabel, self.expand], NSUserInterfaceLayoutOrientationHorizontal, 12);
        self.queue = RFUIStack(@[
            RFUILabel(@"UP NEXT", 10, NSFontWeightSemibold, muted),
            RFUILabel(@"02   A little closer                           03:26", 13, NSFontWeightMedium, white),
            RFUILabel(@"03   City lights                                04:12", 13, NSFontWeightMedium, white),
            RFUILabel(@"04   Slow morning                           02:58", 13, NSFontWeightMedium, white)
        ], NSUserInterfaceLayoutOrientationVertical, 16);
        self.queue.hidden = YES;
        root = RFUIStack(@[hero, timeline, bottom, self.queue], NSUserInterfaceLayoutOrientationVertical, 20);
        root.detachesHiddenViews = YES;
        self.controls = @[previous, self.play, next, self.volume, self.expand];
    }
    root.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:root];
    [NSLayoutConstraint activateConstraints:@[
        [root.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:12],
        [root.topAnchor constraintEqualToAnchor:self.topAnchor constant:8],
        [root.trailingAnchor constraintLessThanOrEqualToAnchor:self.trailingAnchor constant:-12],
        [root.bottomAnchor constraintLessThanOrEqualToAnchor:self.bottomAnchor constant:-8]
    ]];
    [self applySettings];
    if (!RFActiveCardViews) RFActiveCardViews = [NSHashTable weakObjectsHashTable];
    [RFActiveCardViews addObject:self];
    return self;
}
- (void)applySettings {
    NSString *path = RFSetting(@"coverImage", @"");
    self.artwork.image = path.length ? [[NSImage alloc] initWithContentsOfFile:path] : self.bundledArtwork;
    if (self.gallery) return;
    self.trackLabel.stringValue = RFSetting(@"trackTitle", @"After the rain");
    self.subtitleLabel.stringValue = RFSetting(@"subtitle", @"Quiet Hours · Evening Sessions");
    self.volume.doubleValue = [RFSetting(@"defaultVolume", @65) doubleValue];
    [self changeVolume:nil];
    self.artwork.hidden = [RFSetting(@"appearance", @"artwork") isEqualToString:@"hidden"];
    RFCardRequestSize(self, [RFSetting(@"cardWidth", @520) doubleValue], self.expanded ? 472 : 292);
}
- (NSButton *)button:(NSString *)symbol action:(SEL)action {
    return RFUISymbolButton(symbol, symbol, self, action);
}
- (void)togglePlay:(id)sender {
    self.playing = !self.playing;
    self.play.image = [NSImage imageWithSystemSymbolName:self.playing ? @"pause.fill" : @"play.fill" accessibilityDescription:@"播放或暂停"];
}
- (void)previous:(id)sender { self.trackLabel.stringValue = @"Slow morning"; }
- (void)next:(id)sender { self.trackLabel.stringValue = @"City lights"; }
- (void)changeVolume:(id)sender { self.volumeLabel.stringValue = [NSString stringWithFormat:@"音量 %.0f%%", self.volume.doubleValue]; }
- (void)toggleQueue:(id)sender {
    self.expanded = !self.expanded;
    self.queue.hidden = !self.expanded;
    self.expand.title = self.expanded ? @"收起播放列表" : @"展开播放列表";
    RFCardRequestSize(self, [RFSetting(@"cardWidth", @520) doubleValue], self.expanded ? 472 : 292);
}
- (void)highlight {
    [self.controls enumerateObjectsUsingBlock:^(NSControl *control, NSUInteger index, BOOL *stop) {
        RFUISetFocused(control, (NSInteger)index == self.focusIndex);
    }];
}
- (int32_t)remote:(NSString *)event pressed:(BOOL)pressed {
    if ([event isEqualToString:@"leave"]) { self.focusIndex = -1; [self highlight]; return 1; }
    if (!pressed || self.controls.count == 0) return 1;
    if ([event isEqualToString:@"enter"]) self.focusIndex = 1;
    else if (([event isEqualToString:@"left"] || [event isEqualToString:@"right"]) && self.focusIndex == 3) {
        self.volume.doubleValue += [event isEqualToString:@"right"] ? 5 : -5;
        [self changeVolume:nil];
    } else if ([event isEqualToString:@"left"] || [event isEqualToString:@"up"]) self.focusIndex = MAX(0, self.focusIndex - 1);
    else if ([event isEqualToString:@"right"] || [event isEqualToString:@"down"]) self.focusIndex = MIN((NSInteger)self.controls.count - 1, self.focusIndex + 1);
    else if ([event isEqualToString:@"ok"] && self.focusIndex >= 0) {
        NSControl *control = self.controls[self.focusIndex];
        if ([control isKindOfClass:NSButton.class]) [(NSButton *)control performClick:nil];
    }
    [self highlight];
    return 1;
}
@end

uint32_t remoteflow_menu_abi_version(void) { return REMOTEFLOW_CARD_ABI_VERSION; }
const char *remoteflow_menu_content(void) {
    NSMutableArray *cards = [NSMutableArray arrayWithObject:@{@"id": @"player", @"title": @"音乐卡片",
        @"preferredWidth": RFSetting(@"cardWidth", @520), @"preferredHeight": @292}];
    if ([RFSetting(@"showImageCard", @YES) boolValue]) {
        [cards addObject:@{@"id": @"image", @"title": @"图片卡片", @"preferredWidth": @280, @"preferredHeight": @292}];
    }
    RFContentJSON = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:cards options:0 error:nil] encoding:NSUTF8StringEncoding];
    return RFContentJSON.UTF8String;
}
void *remoteflow_card_create_view(const char *card_id, const char *bundle_path) {
    NSString *path = [[NSString stringWithUTF8String:bundle_path] stringByAppendingPathComponent:@"Contents/Resources/Artwork.png"];
    NSImage *image = [[NSImage alloc] initWithContentsOfFile:path];
    if (!image) return NULL;
    return (__bridge_retained void *)[[RFDemoRichCardView alloc] initWithImage:image gallery:strcmp(card_id, "image") == 0];
}
int32_t remoteflow_card_handle_remote(void *view, const char *event, int32_t pressed) {
    return [(__bridge RFDemoRichCardView *)view remote:[NSString stringWithUTF8String:event] pressed:pressed != 0];
}
void remoteflow_card_will_close(void *view) {
    [RFActiveCardViews removeObject:(__bridge RFDemoRichCardView *)view];
}

const char *remoteflow_plugin_apply_settings(const char *json) {
    NSData *data = [[NSString stringWithUTF8String:json] dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *settings = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (![settings isKindOfClass:NSDictionary.class]) return "设置必须是 JSON 对象";
    NSString *title = settings[@"trackTitle"];
    if (title && title.length == 0) return "曲目名称不能为空";
    NSString *path = settings[@"coverImage"];
    if (path.length && ![[NSImage alloc] initWithContentsOfFile:path]) return "无法读取所选封面图片";
    // Validate before changing any global or view state.
    RFCardSettings = settings.copy;
    for (RFDemoRichCardView *view in RFActiveCardViews.allObjects) [view applySettings];
    return NULL;
}
