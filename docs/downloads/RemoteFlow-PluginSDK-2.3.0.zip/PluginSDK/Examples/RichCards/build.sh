#!/bin/zsh
set -euo pipefail
example_dir="${0:A:h}"
output="${1:-/private/tmp/RichCards.bundle}"
mkdir -p "$output/Contents/MacOS" "$output/Contents/Resources"
cat > "$output/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.remoteflow.example.richcards</string>
<key>CFBundleExecutable</key><string>RichCards</string>
<key>CFBundlePackageType</key><string>BNDL</string>
<key>CFBundleVersion</key><string>2</string>
</dict></plist>
PLIST
cat > "$output/Contents/Resources/menu-plugin.json" <<'JSON'
{"schemaVersion":1,"identifier":"com.remoteflow.example.richcards","version":"2.1.0","author":"RemoteFlow SDK","title":"原生图片与音乐卡片","symbolName":"rectangle.on.rectangle"}
JSON
cp "$example_dir/Resources/Artwork.png" "$output/Contents/Resources/Artwork.png"
cp "$example_dir/Resources/settings.json" "$output/Contents/Resources/settings.json"
xcrun clang -bundle -fobjc-arc -mmacosx-version-min=14.0 -framework AppKit -framework QuartzCore \
  "$example_dir/RichCards.m" -o "$output/Contents/MacOS/RichCards"
codesign --force --sign "${CODE_SIGN_IDENTITY:--}" "$output"
echo "$output"
