#import <AppKit/AppKit.h>
#include "../../RemoteFlowMenuPlugin.h"
#include <string.h>

static BOOL expanded = NO;
static NSString *contentJSON;

uint32_t remoteflow_menu_abi_version(void) { return REMOTEFLOW_MENU_ABI_VERSION; }
const char *remoteflow_menu_content(void) {
    NSMutableArray *entries = [@[
        @{@"id": @"hello", @"title": @"原生插件问候", @"symbolName": @"hand.wave"},
        @{@"id": @"finder", @"title": @"插件打开 Finder", @"symbolName": @"folder"},
        @{@"id": @"toggle-layout", @"title": expanded ? @"下次收起示例内容" : @"下次展开更多示例内容",
          @"symbolName": @"arrow.up.left.and.arrow.down.right"}
    ] mutableCopy];
    if (expanded) {
        for (NSUInteger index = 1; index <= 21; index++) {
            [entries addObject:@{@"id": [NSString stringWithFormat:@"demo-%lu", (unsigned long)index],
                                 @"title": [NSString stringWithFormat:@"自适应内容 %lu", (unsigned long)index],
                                 @"symbolName": @"square.grid.2x2"}];
        }
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:entries options:0 error:nil];
    // Retain the UTF-8 backing storage until the next content call.
    contentJSON = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return contentJSON.UTF8String;
}
const char *remoteflow_menu_execute(const char *command_id) {
    if (strcmp(command_id, "toggle-layout") == 0) {
        expanded = !expanded;
        return NULL;
    }
    if (strncmp(command_id, "demo-", 5) == 0) {
        // Demonstrate routing without opening any other application.
        return NULL;
    }
    if (strcmp(command_id, "hello") == 0) {
        NSAlert *alert = [NSAlert new];
        alert.messageText = @"Hello from a native menu plugin";
        alert.informativeText = @"显示内容与执行操作均由独立编译的插件提供。";
        [alert runModal];
        return NULL;
    }
    if (strcmp(command_id, "finder") == 0) {
        return [[NSWorkspace sharedWorkspace] openURL:[NSURL fileURLWithPath:NSHomeDirectory()]]
            ? NULL : "Could not open Finder";
    }
    return "Unknown command";
}
