#!/bin/zsh
set -euo pipefail
example_dir="${0:A:h}"
output="${1:-/private/tmp/HelloMenu.bundle}"
mkdir -p "$output/Contents/MacOS" "$output/Contents/Resources"
cat > "$output/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.remoteflow.example.hello</string>
<key>CFBundleExecutable</key><string>HelloMenu</string>
<key>CFBundlePackageType</key><string>BNDL</string>
<key>CFBundleVersion</key><string>2</string>
</dict></plist>
PLIST
cat > "$output/Contents/Resources/menu-plugin.json" <<'JSON'
{"schemaVersion":1,"identifier":"com.remoteflow.example.hello","version":"1.1.0","author":"RemoteFlow SDK","title":"Hello 原生插件","symbolName":"puzzlepiece.extension"}
JSON
xcrun clang -bundle -fobjc-arc -mmacosx-version-min=14.0 -framework AppKit \
  "$example_dir/HelloMenu.m" -o "$output/Contents/MacOS/HelloMenu"
# For distribution, pass the same Developer ID identity as the host app.
codesign --force --sign "${CODE_SIGN_IDENTITY:--}" "$output"
echo "$output"
