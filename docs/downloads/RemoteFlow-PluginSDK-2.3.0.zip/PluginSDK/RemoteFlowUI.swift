import SwiftUI

/// Add this source to a SwiftUI plugin target; no host-specific Swift module is linked.
public enum RFUITheme {
    public static let accent = Color(red: 0, green: 106.0 / 255, blue: 1)
    public static let surface = Color(white: 26.0 / 255)
    public static let text = Color.white
    public static let secondaryText = Color(white: 0.7)
    public static let spacing: CGFloat = 12
    public static let cornerRadius: CGFloat = 20
}

public struct RFUISection<Content: View>: View {
    private let title: String
    private let content: Content

    public init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: RFUITheme.spacing) {
            Text(title).font(.system(size: 14, weight: .semibold)).foregroundStyle(RFUITheme.text)
            content
        }
        .padding(15)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RFUITheme.surface, in: RoundedRectangle(cornerRadius: RFUITheme.cornerRadius))
        .tint(RFUITheme.accent)
    }
}

public struct RFUIButton: View {
    private let title: String
    private let primary: Bool
    private let action: () -> Void

    public init(_ title: String, primary: Bool = true, action: @escaping () -> Void) {
        self.title = title
        self.primary = primary
        self.action = action
    }

    public var body: some View {
        Group {
            if primary { Button(title, action: action).buttonStyle(.borderedProminent) }
            else { Button(title, action: action).buttonStyle(.bordered) }
        }
        .tint(RFUITheme.accent)
    }
}

public extension View {
    /// The plugin still decides which internal control is focused by remote events.
    func rfRemoteFocused(_ focused: Bool) -> some View {
        overlay {
            RoundedRectangle(cornerRadius: 8)
                .strokeBorder(focused ? RFUITheme.accent : .clear, lineWidth: 2)
                .allowsHitTesting(false)
        }
    }
}
