#ifndef REMOTEFLOW_PROGRESS_LAYOUT_H
#define REMOTEFLOW_PROGRESS_LAYOUT_H

// Standard progress-card geometry in points. Width is chosen by the plugin.
// Fixed by the SDK: the bar is display-only; elapsed/total time sits above it.
#define RFProgressCardHeight 180.0
#define RFProgressBarHeight 3.0
#define RFProgressBarSideInset 22.0
#define RFProgressBarBottomInset 18.0
#define RFProgressCaptionGap 7.0

#endif
